# -*- coding: utf-8 -*-

from odoo import api, fields, models, _
from odoo.exceptions import UserError, ValidationError


class UsersInherit(models.Model):
	_inherit = 'res.users'

	fixed_limit = fields.Float(string="Fixed Limit")
	percent_limit = fields.Float(string="Percentage Limit")

class SaleOrderInherit(models.Model):
	_inherit = 'sale.order'

	limit_type = fields.Selection([
        ('fix', 'Fixed Limit'),
        ('percent', 'Percentage Limit'),
    ], help="Select the discount limit type.")


class SaleOrderLineInherit(models.Model):
	_inherit = 'sale.order.line'

	@api.onchange('discount')
	def calculate_discount(self):
		for discount_amount in self:
			new_amount = (discount_amount.price_unit * discount_amount.product_uom_qty * discount_amount.discount)/100 

			for new_u_id in self.order_id.user_id:

				if self.order_id.limit_type == 'fix':
					if new_u_id.fixed_limit != 0.0 and self.env.user.fixed_limit < self.discount:
						msg = _('Discount amount must be less than or equal to %s!') % (new_u_id.fixed_limit, )
						raise UserError(msg)

				if self.order_id.limit_type == 'percent':
					if new_u_id.percent_limit != 0.0 and self.env.user.percent_limit < self.discount:
						msg = _('Discount percent must be less than or equal to %s!') % (new_u_id.percent_limit, )
						raise UserError(msg)
